#!/bin/sh
# Полная пересборка MTR: чистка Docker и сборка с нуля.
#
# Зачем: несколько раз образ собирался из смеси файлов — версия 0.16.0,
# а команды и Pillow от 0.14.0. Docker кеширует слой `pip install` отдельно
# от кода, поэтому при старом requirements.txt он переиспользует старый слой,
# даже если код новый. Единственный надёжный способ — собрать без кеша,
# предварительно удалив образ.
#
# ВАЖНО: скрипт НЕ трогает данные. Базы, ключ шифрования и кэш обложек
# лежат на хосте в каталоге, смонтированном в /data. Он остаётся нетронутым.
# Удаляются только контейнер и образ.
#
# Запуск (из каталога проекта на NAS):
#   sh scripts/clean-rebuild.sh
#
# Если что-то пойдёт не так — данные всё равно на месте, их не касаемся.

set -eu

PROJECT_DIR=$(cd "$(dirname "$0")/.." && pwd)
cd "$PROJECT_DIR"

CONTAINER=mtr-app

printf '\n[1] Проверка каталога данных\n'
DATA_DIR_HOST=/share/CACHEDEV1_DATA/Container/mtr-data
if [ -d "$DATA_DIR_HOST" ]; then
    count=$(ls -1 "$DATA_DIR_HOST" 2>/dev/null | wc -l)
    printf '  %s: %s объектов (не трогаем)\n' "$DATA_DIR_HOST" "$count"
    if [ -f "$DATA_DIR_HOST/secret.key" ]; then
        printf '=> secret.key на месте — пароли останутся читаемыми\n'
    else
        printf '=> ВНИМАНИЕ: secret.key нет. Если это не первый запуск,\n'
        printf '=> сохранённые пароли будут нечитаемы. Проверьте путь.\n'
    fi
else
    printf '=> каталог %s не найден — проверьте путь в docker-compose.yml\n' "$DATA_DIR_HOST"
fi

printf '\n[2] Остановка и удаление контейнера\n'
docker rm -f "$CONTAINER" 2>/dev/null && printf '=> удалён\n' || printf '  контейнера не было\n'

printf '\n[3] Удаление старых образов MTR\n'
for image in $(docker images --format '{{.Repository}}:{{.Tag}}' | grep '^mtr-app:' || true); do
    docker rmi -f "$image" >/dev/null 2>&1 && printf '=> удалён %s\n' "$image" || printf '=> не удалось удалить %s\n' "$image"
done

printf '\n[4] Чистка кеша сборки\n'
docker builder prune -af >/dev/null 2>&1 && printf '=> кеш сборки очищен\n' || printf '=> не удалось очистить кеш\n'

printf '\n[5] Сборка без кеша (на armv7 это долго, до 10 минут) ==\n'
if ! docker compose build --no-cache; then
    printf '\nСБОРКА УПАЛА. Последние строки выше показывают причину.\n'
    printf 'Если это pip install Pillow — пришлите вывод целиком.\n'
    exit 1
fi

printf '\n[6] Запуск\n'
docker compose up -d

printf '\n[7] Ожидание готовности\n'
i=0
while [ "$i" -lt 30 ]; do
    if docker exec "$CONTAINER" python -c "import urllib.request,sys; sys.exit(0 if urllib.request.urlopen('http://127.0.0.1:4533/healthz', timeout=2).status==200 else 1)" 2>/dev/null; then
        printf '=> сервер отвечает\n'
        break
    fi
    i=$((i + 1))
    sleep 2
done

printf '\n[8] Самопроверка\n'
docker exec "$CONTAINER" sh /app/scripts/selfcheck.sh || {
    printf '\nОбраз собран не полностью.\n'
    exit 1
}

printf '\n[9] Что дальше\n'
printf '=> Замер обложек (кеш пуст после чистки? очистите отдельно):\n'
printf 'docker exec -it %s python -m app.cli covers --purge\n' "$CONTAINER"
printf 'docker exec -it %s sh -c '"'"'S=$(date +%%s); python -m app.cli covers --limit 60; echo "прошло $(( $(date +%%s) - S )) с"'"'"'\n' "$CONTAINER"
printf '\nГотово.\n'
